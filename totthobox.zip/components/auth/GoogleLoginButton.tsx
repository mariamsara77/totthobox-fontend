"use client";

import { useState } from "react";
import { GoogleOAuthProvider, useGoogleLogin } from "@react-oauth/google";
import { useAuth } from "@/context/AuthContext";

type Props = {
  onLoginSuccess?: () => void | Promise<void>;
};

function CustomButton({ onLoginSuccess }: Props) {
  const { mutateUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const login = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      setLoading(true);
      setError(null);

      try {
        const res = await fetch("/api/auth/google", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            access_token: tokenResponse.access_token,
          }),
        });

        const data = await res.json().catch(() => null);

        if (!res.ok) {
          throw new Error(
            data?.message || "Google দিয়ে লগইন করা যায়নি। আবার চেষ্টা করুন।",
          );
        }

        await mutateUser();
        await onLoginSuccess?.();
      } catch (err) {
        setError(
          err instanceof Error
            ? err.message
            : "Google দিয়ে লগইন করা যায়নি। আবার চেষ্টা করুন।",
        );
      } finally {
        setLoading(false);
      }
    },
    onError: () => {
      setError("Google সাইন ইন বাতিল হয়েছে বা ব্যর্থ হয়েছে। আবার চেষ্টা করুন।");
      setLoading(false);
    },
  });

  return (
    <div className="w-full">
      <button
        type="button"
        disabled={loading}
        onClick={() => {
          setLoading(true);
          setError(null);
          login();
        }}
        className="group flex w-full items-center justify-center gap-3 rounded-full border border-zinc-400/25 bg-zinc-400/10 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-zinc-400/25 disabled:cursor-not-allowed disabled:opacity-60 dark:text-zinc-100"
      >
        {loading ? (
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-zinc-500 border-t-transparent" />
        ) : (
          <svg className="h-5 w-5" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
          </svg>
        )}
        {loading ? "Google দিয়ে লগইন হচ্ছে..." : "Google দিয়ে সাইন ইন করুন"}
      </button>

      {error && (
        <p role="alert" className="mt-2 text-center text-sm text-zinc-500 dark:text-zinc-400">
          {error}
        </p>
      )}
    </div>
  );
}

export default function GoogleLoginButton({ onLoginSuccess }: Props) {
  const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;

  if (!clientId) {
    return (
      <p role="alert" className="text-center text-sm text-zinc-500">
        Google লগইন বর্তমানে কনফিগার করা নেই।
      </p>
    );
  }

  return (
    <GoogleOAuthProvider clientId={clientId}>
      <CustomButton onLoginSuccess={onLoginSuccess} />
    </GoogleOAuthProvider>
  );
}

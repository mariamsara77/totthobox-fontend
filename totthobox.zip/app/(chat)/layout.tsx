import type { Metadata, Viewport } from "next";
import { ChatLayoutProvider } from "@/context/ChatLayoutContext";

export const metadata: Metadata = {
  title: {
    default: "মেসেজ | Totthobox",
    template: "%s | Totthobox",
  },
  description: "Totthobox-এর আধুনিক ব্যক্তিগত মেসেজিং।",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#ffffff",
  colorScheme: "light dark",
};

export default function ChatLayout({ children }: { children: React.ReactNode }) {
  return (
    <div
      className={`chat-layout-root pwa-screen-height min-h-0 w-full overflow-hidden overscroll-none`}
    >
      <ChatLayoutProvider>
        <main className="flex h-full min-h-0 w-full min-w-0 overflow-hidden">
          {children}
        </main>
      </ChatLayoutProvider>
    </div>
  );
}
